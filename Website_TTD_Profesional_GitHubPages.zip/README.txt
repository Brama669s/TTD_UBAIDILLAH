UPLOAD KE GITHUB PAGES

1. Buat akun GitHub.
2. Buat repository baru.
3. Upload seluruh isi folder ini.
4. Settings > Pages.
5. Source = Deploy from branch.
6. Branch = main / root.
7. Simpan.

Link akan menjadi:
https://username.github.io/nama-repository/

Alternatif Netlify:
- Drag & drop folder ini ke https://app.netlify.com/drop
